from fastapi import FastAPI
from pydantic import BaseModel
from agents.content_agent import ContentAgent
from agents.crm_agent import CRMAgent
from agents.review_agent import ReviewAgent

app = FastAPI(title="AI Automation Agent MVP")

content_agent = ContentAgent()
crm_agent = CRMAgent()
review_agent = ReviewAgent()


class TopicRequest(BaseModel):
    topic: str


class CustomerRequest(BaseModel):
    message: str


class FlightLogRequest(BaseModel):
    log: str


@app.get("/")
def root():
    return {"status": "running", "project": "AI Automation Agent MVP"}


@app.post("/generate-content")
def generate_content(req: TopicRequest):
    result = content_agent.generate_post(req.topic)
    return {"result": result}


@app.post("/analyze-customer")
def analyze_customer(req: CustomerRequest):
    result = crm_agent.analyze_customer(req.message)
    return {"result": result}


@app.post("/generate-review")
def generate_review(req: FlightLogRequest):
    result = review_agent.generate_review(req.log)
    return {"result": result}