from openai import OpenAI
from config import OPENAI_API_KEY, MODEL_NAME

client = OpenAI(api_key=OPENAI_API_KEY)


class CRMAgent:

    def analyze_customer(self, customer_message):

        prompt = f'''
请分析该用户的购买意向：

等级：
- 高意向
- 中意向
- 低意向

并输出销售建议。

用户消息：
{customer_message}
'''

        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content