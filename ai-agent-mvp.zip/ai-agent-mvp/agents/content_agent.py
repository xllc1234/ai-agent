from openai import OpenAI
from config import OPENAI_API_KEY, MODEL_NAME

client = OpenAI(api_key=OPENAI_API_KEY)


class ContentAgent:

    def generate_post(self, topic):

        prompt = f'''
你是一名专业无人机行业运营专家。

请输出：
1. 小红书文案
2. 抖音脚本
3. 标题
4. 引导语

主题：{topic}
'''

        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content