from openai import OpenAI
from config import OPENAI_API_KEY, MODEL_NAME

client = OpenAI(api_key=OPENAI_API_KEY)


class ReviewAgent:

    def generate_review(self, flight_log):

        prompt = f'''
请根据以下无人机飞行日志生成训练评估报告：

{flight_log}
'''

        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content