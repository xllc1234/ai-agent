# AI Automation Agent MVP

## 功能

- Content Agent（内容生成）
- CRM Agent（客户意向分析）
- Review Agent（飞行日志评估）
- FastAPI API 服务
- OpenAI API 接入

---

## 安装

```bash
pip install -r requirements.txt
```

复制环境变量：

```bash
cp .env.example .env
```

填写你的 OpenAI KEY。

---

## 启动

```bash
uvicorn main:app --reload
```

---

## API 文档

启动后访问：

```bash
http://127.0.0.1:8000/docs
```

---

## 测试接口

### 内容生成

POST:

```bash
/generate-content
```

Body:

```json
{
  "topic": "CAAC无人机考证"
}
```

---

### 客户分析

POST:

```json
{
  "message": "我想学习无人机"
}
```

---

### 飞行日志评估

POST:

```json
{
  "log": "飞行高度120米，出现偏航"
}
```